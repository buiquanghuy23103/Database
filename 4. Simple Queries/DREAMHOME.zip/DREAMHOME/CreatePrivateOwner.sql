IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_NAME = N'PrivateOwner')
BEGIN
	SET ANSI_NULLS ON
	SET QUOTED_IDENTIFIER ON

	CREATE TABLE [dbo].[PrivateOwner](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[FirstName] [nvarchar](50) NOT NULL,
		[FamilyName] [nvarchar](50) NOT NULL,
		[Street] [nvarchar](50) NOT NULL,
		[City] [nvarchar](50) NOT NULL,
		[Postcode] [nvarchar](50) NOT NULL,
		[TelephoneNumber] [nvarchar](50) NOT NULL,
		[Email] [nvarchar](254) NOT NULL,
	CONSTRAINT [PK_PrivateOwner] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]
	PRINT 'Table PrivateOwner successfully created.'
END
ELSE
	PRINT 'You already have table PrivateOwner created.'