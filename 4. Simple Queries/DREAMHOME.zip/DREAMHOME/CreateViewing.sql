IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_NAME = N'Viewing')
BEGIN
	SET ANSI_NULLS ON
	SET QUOTED_IDENTIFIER ON

	CREATE TABLE [dbo].[Viewing](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[ClientId] [int] NOT NULL,
		[PropertyForRentId] [int] NOT NULL,
		[ViewDate] [datetime] NOT NULL,
		[CommentsGiven] [nvarchar](254) NULL,
	CONSTRAINT [PK_Viewing] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	ALTER TABLE [dbo].[Viewing]  WITH CHECK ADD  CONSTRAINT [FK_Viewing_Client] FOREIGN KEY([ClientId])
	REFERENCES [dbo].[Client] ([Id])

	ALTER TABLE [dbo].[Viewing] CHECK CONSTRAINT [FK_Viewing_Client]

	ALTER TABLE [dbo].[Viewing]  WITH CHECK ADD  CONSTRAINT [FK_Viewing_PropertyForRent] FOREIGN KEY([PropertyForRentId])
	REFERENCES [dbo].[PropertyForRent] ([Id])

	ALTER TABLE [dbo].[Viewing] CHECK CONSTRAINT [FK_Viewing_PropertyForRent]
	PRINT 'Table Viewing successfully created.'
END
ELSE
	PRINT 'You already have table Viewing created.'