IF NOT EXISTS(SELECT * FROM sys.databases WHERE name = 'DREAMHOME')
    CREATE database DREAMHOME
ELSE
	PRINT 'You already have database DREAMHOME created.'
GO
USE [DREAMHOME]
GO
:setvar path "C:\Users\Student\Documents\SQL Server Management Studio\DREAMHOME\"
:r $(path)\CreateBranch.sql
:r $(path)\CreateStaff.sql
:r $(path)\CreatePrivateOwner.sql
:r $(path)\CreatePropertyForRent.sql
:r $(path)\CreateClient.sql
:r $(path)\CreateViewing.sql
:r $(path)\InsertBranch.sql
:r $(path)\InsertStaff.sql
:r $(path)\InsertPrivateOwner.sql
:r $(path)\InsertPropertyForRent.sql
:r $(path)\InsertClient.sql
:r $(path)\InsertViewing.sql