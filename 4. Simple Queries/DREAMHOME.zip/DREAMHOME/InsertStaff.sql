-- REMEMBER UTF-8 ENCODING
IF NOT EXISTS (SELECT * FROM Staff)
BEGIN
	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'John', N'White', N'Manager', 'M', '1945-10-01', 30090.55, 1)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Justin', N'Case', N'Estate Agent', 'F', '1958-11-01', 25290.95, 1)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Mary', N'Howe', N'Assistant', 'F', '1970-02-19', 9007.65, 2)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Lee', N'Walker', N'Estate Agent', 'M', '1972-12-19', 19034.65, 2)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Ann', N'Beech', N'Assistant', 'F', '1960-11-10', 12030.45, 3)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'David', N'Ford', N'Supervisor', 'M', '1958-03-24', 18050.75, 3)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'April', N'Showers', N'Estate Agent', 'F', '1963-01-24', 20051.15, 3)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Susan', N'Brand', N'Manager', 'F', '1940-06-03', 24030.85, 3)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Julie', N'Lee', N'Assistant', 'F', '1965-06-13', 9090.85, 4)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Cris', N'Cross', N'Estate Agent', 'F', '1967-09-23', 23190.35, 4)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Chrystal', N'Cameron', N'Controller', 'F', '1979-08-22', 39090.45, 4)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Hana', N'Alburg', N'Assistant', 'F', '1977-05-20', 10090.25, 1)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Hadley', N'Bailor', N'Supervisor', 'F', '1998-11-11', 19030.75, 1)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Octavia', N'Callaway', N'Controller', 'F', '1999-12-24', 41790.95, 1)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Ollie', N'Byrom', N'Manager', 'F', '1969-01-01', 32790.15, 2)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Talisha', N'Ditton', N'Supervisor', 'F', '1959-10-05', 21095.45, 2)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Ubon', N'Edginton', N'Manager', 'F', '1986-03-07', 27590.35, 2)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Lakeisha', N'Mallet', N'Manager', 'F', '1988-05-07', 38890.75, 5)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Abbey', N'Felton', N'Controller', 'M', '1981-08-12', 42790.95, 5)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Kagan', N'Kalton', N'Estate Agent', 'M', '1969-01-04', 25590.55, 5)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Pacey', N'Hailstone', N'Assistant', 'M', '1955-04-12', 11020.45, 5)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Vadin', N'Justice', N'Controller', 'F', '1979-08-22', 39090.45, 3)

	INSERT INTO [dbo].[Staff]
           ([FirstName]
           ,[FamilyName]
           ,[Position]
           ,[Gender]
           ,[DateOfBirth]
           ,[Salary]
           ,[BranchId])
     VALUES
           (N'Maceo', N'Lanning', N'Supervisor', 'M', '1972-04-27', 20390.35, 5)
	PRINT 'Information added successfully to table Staff.'
END
ELSE
	PRINT 'You already have the Staff information added.'