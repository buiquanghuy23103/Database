-- REMEMBER UTF-8 ENCODING
IF NOT EXISTS (SELECT * FROM Client)
BEGIN
	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'John', N'Kay', N'0207-774-5632', N'Flat', 425, N'john.kay@gmail.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Aline', N'Stewart', N'0141-848-1825', N'Flat', 350, N'aline.stewart@gmail.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Mike', N'Ritchie', N'0147-391-8878', N'House', 750, N'mike.ritchie@bigfoot.co.uk')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Hope', N'Springs', N'0142-119-2178', N'House', 690, N'optimistic@angelfire.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Mary', N'Tregear', N'0122-779-1967', N'Flat', 600, N'mary.tregar@crosswinds.net')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Aspen', N'Marriott', N'0339-895-5684', N'Flat', 575, N'aspen.marriott@joinme.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Minnie', N'Miles', N'9871-089-1564', N'Bungalow', 875, N'million.miles@allracing.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Cael', N'Metcalf', N'3311-111-7567', N'House', 885, N'cael.metcalf@godaddy.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Daewon', N'Needley', N'5571-033-1507', N'House', 875, N'needless.tosay@fastmail.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Salomon', N'Savell', N'9866-933-1561', N'Villa', 735, N'salomon.save@protonmail.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Wade', N'Ozier', N'6671-551-1564', N'Villa', 760, N'wade.ozzie@rackspace.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Abigail', N'Pidcock', N'9881-551-5564', N'Villa', 810, N'abi.pidcock@gsuite.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Whitley', N'Quinton', N'1171-178-3564', N'Villa', 795, N'whitley.quinton@flaskmail.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Raelyn', N'Roley', N'8871-489-1555', N'Cottage', 550, N'rae.role@goodbit.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Bailey', N'Shorrock', N'1589-077-7164', N'Villa', 990, N'bailey.sherr@dudamobile.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Helen', N'Spikes', N'1671-060-2564', N'Bungalow', 970, N'helen.spike@instapage.com')

	INSERT INTO [dbo].[Client]
           ([FirstName]
           ,[FamilyName]
           ,[TelephoneNumber]
           ,[PreferredType]
           ,[MaxRentPossible]
           ,[Email])
     VALUES
           (N'Uschi', N'Tipton', N'8870-777-7564', N'Cottage', 430, N'uschie.firsttip@unbounce.com')
	PRINT 'Information added successfully to table Client.'
END
ELSE
	PRINT 'You already have the Client information added.'
