-- REMEMBER UTF-8 ENCODING
IF NOT EXISTS (SELECT * FROM PrivateOwner)
BEGIN
	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Joe', N'Keogh', N'2 Fergus Drive', N'Aberdeen', N'AB2 7SX', N'0124-861-5212', N'joe.keogh@gmail.com')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Carol', N'Farrel', N'6 Achray Street', N'Glasgow', N'G32 9DX', N'0141-357-7419', N'carol.farrel@hiphopfan.com')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Tina', N'Murphy', N'63 Well Street', N'Glasgow', N'G42 4HD', N'0141-943-1728', N'morning.sun@ark.com')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Tony', N'Shaw', N'12 Park Plaza', N'Glasgow', N'G04 0QR', N'0141-225-7025', N'tony.shaw@windrivers.net')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Quinn', N'Welborne', N'Northumberland Road', N'Bristol', N'B77 0QR', N'5566-725-7025', N'quinn.well@megafon.net')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Xaviera', N'Tomson', N'Lower Redland Road', N'Bristol', N'B43 0QL', N'3777-229-9025', N'xaviera.tomson@chainref.net')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Zaida', N'Tyrrell', N'Claremont Street', N'Aberdeen', N'A04 7KR', N'6678-825-2025', N'zaida.tyrrell@orange.net')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Nadine', N'Vanstone', N'Ilderton Road', N'London', N'L04 6FR', N'0678-888-1325', N'nadine.vanstone@optus.net')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Qadir', N'Usher', N'Lomond Grove', N'London', N'H54 9SS', N'8900-761-0025', N'qadir.usher@vodafone.net')

	INSERT INTO [dbo].[PrivateOwner]
           ([FirstName]
           ,[FamilyName]
           ,[Street]
           ,[City]
           ,[Postcode]
           ,[TelephoneNumber]
           ,[Email])
     VALUES
           (N'Weldon', N'Zane', N'St George''s Way', N'London', N'X91 5LL', N'2341-902-7654', N'weldon.zane@citycell.net')
	PRINT 'Information added successfully to table PrivateOwner.'
END
ELSE
	PRINT 'You already have the PrivateOwner information added.'