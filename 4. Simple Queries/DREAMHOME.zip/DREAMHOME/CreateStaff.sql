IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_NAME = N'Staff')
BEGIN
	SET ANSI_NULLS ON
	SET QUOTED_IDENTIFIER ON
	SET ANSI_PADDING ON

	CREATE TABLE [dbo].[Staff](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[FirstName] [nvarchar](50) NOT NULL,
		[FamilyName] [nvarchar](50) NOT NULL,
		[Position] [nvarchar](50) NOT NULL,
		[Gender] [char](1) NOT NULL,
		[DateOfBirth] [datetime] NOT NULL,
		[Salary] [decimal](8, 2) NOT NULL,
		[BranchId] [int] NOT NULL,
	CONSTRAINT [PK_Staff] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]

	SET ANSI_PADDING OFF

	ALTER TABLE [dbo].[Staff]  WITH CHECK ADD  CONSTRAINT [FK_Staff_Branch] FOREIGN KEY([BranchId])
	REFERENCES [dbo].[Branch] ([Id])

	ALTER TABLE [dbo].[Staff] CHECK CONSTRAINT [FK_Staff_Branch]
	PRINT 'Table Staff successfully created.'
END
ELSE
	PRINT 'You already have table Staff created.'