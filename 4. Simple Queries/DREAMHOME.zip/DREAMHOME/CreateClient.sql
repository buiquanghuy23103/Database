IF NOT EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES 
           WHERE TABLE_NAME = N'Client')
BEGIN
	SET ANSI_NULLS ON
	SET QUOTED_IDENTIFIER ON

	CREATE TABLE [dbo].[Client](
		[Id] [int] IDENTITY(1,1) NOT NULL,
		[FirstName] [nvarchar](50) NOT NULL,
		[FamilyName] [nvarchar](50) NOT NULL,
		[TelephoneNumber] [nvarchar](50) NOT NULL,
		[PreferredType] [nvarchar](50) NOT NULL,
		[MaxRentPossible] [decimal](8, 2) NOT NULL,
		[Email] [nvarchar](254) NOT NULL,
	CONSTRAINT [PK_Client] PRIMARY KEY CLUSTERED 
	(
		[Id] ASC
	)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
	) ON [PRIMARY]
	PRINT 'Table Client successfully created.'
END
ELSE
	PRINT 'You already have table Client created.'